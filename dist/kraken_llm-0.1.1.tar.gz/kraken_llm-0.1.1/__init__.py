"""
Kraken LLM - Universal LLM framework with full OpenAI API support.
"""

__version__ = "0.1.0"